﻿/*
    {Mod Title}
    {Mod Copyright} by {Mod Author}

    * Description *
    {Mod Description}

    * License *
    {Mod License}
*/

using MelonLoader;
using SilicaAdminMod;

// this should match the choice for namespace
using Silica_MelonLoader_Mod;

// to build for both the client (net6.0) and the dedicated server (netstandard2.1) some (minimal) conditional compiler directives are necessary
// if we're building for the client then we need to include the Il2Cpp namespace
#if NET6_0
using Il2Cpp;
#endif

// the first parameter of MelonInfo should be the class that inherits from MelonMod (e.g., x : MelonMod)
[assembly: MelonInfo(typeof(HelloWorldMod), "{Mod Title}", "1.0.0", "{Mod Author}", "{Mod Download URL}")]
// do not change any information in MelonGame or the mod will not be loaded by MelonLoader
[assembly: MelonGame("Bohemia Interactive", "Silica")]
[assembly: MelonOptionalDependencies("Admin Mod")]

namespace Silica_MelonLoader_Mod
{
    // an inherited class from the MelonMod class is required for MelonLoader to function
    // see: https://melonwiki.xyz/#/modders/quickstart?id=the-melonmod-class
    public class HelloWorldMod : MelonMod
    {
        // MelonLoader preferences are grouped into categories
        // these will be initialized to null but we can safely tell the compiler these are non-null (null forgiving operator) because OnInitializeMelon will set these
        static MelonPreferences_Category _modCategory = null!;
        // use the "Silica" category name for any general Silica mod preferences or a custom category for larger mods
        const string ModCategory = "Silica";

        // create MelonPreferences_Entry items
        static MelonPreferences_Entry<string> _Hello_Response_Prefix_Text = null!;
        static MelonPreferences_Entry<bool> _Hello_Response_Use_Colon_Seperator = null!;
        static MelonPreferences_Entry<string> _SecretNumber_Prefix_Text = null!;
        static MelonPreferences_Entry<int> _SecretNumber = null!;

        public override void OnInitializeMelon()
        {
            // initialize any preference entries
            // use the null coalescing assignment operator here since OnInitializeMelon will be the first to assign these from their null values
            _modCategory ??= MelonPreferences.CreateCategory(ModCategory);

            _Hello_Response_Prefix_Text ??= _modCategory.CreateEntry<string>("Hello_Response_Message_Prefix", "Hello world to");
            _Hello_Response_Use_Colon_Seperator ??= _modCategory.CreateEntry<bool>("Hello_Response_Colon_Seperator", true);
            _SecretNumber_Prefix_Text ??= _modCategory.CreateEntry<string>("Secret_Response_Message_Prefix", "Answer to the Ultimate Question of Life, The Universe, and Everything: ");
            _SecretNumber ??= _modCategory.CreateEntry<int>("Secret_Response_Number", 42);
        }

        public override void OnLateInitializeMelon()
        {
            // register a text admin command
            // admins with the mod Generic power or game admins will be able to run this command by typing:
            // "!hello" or "/hello" in all chat
            // server operators will be able to run this command by typing: "sam_hello" in the server console
            HelperMethods.CommandCallback helloWorldCallback = Command_HelloWorld;
            HelperMethods.RegisterAdminCommand("hello", helloWorldCallback, Power.Generic);

            // register a text player command
            // any (non-silenced) player can run this command by typing:
            // "!secret" or "/secret" in all chat
            HelperMethods.CommandCallback secretCallback = Command_Secret;
            HelperMethods.RegisterPlayerCommand("secret", secretCallback, false);
        }

        public void Command_HelloWorld(Player? callerPlayer, string args)
        {
            string commandName = args.Split(' ')[0];

            // validate argument count
            int argumentCount = args.Split(' ').Length - 1;
            if (argumentCount > 1)
            {
                HelperMethods.SendChatMessageToPlayer(callerPlayer, HelperMethods.chatPrefix, commandName, " usage: " + commandName + " <player>");
                return;
            }
            else if (argumentCount < 1)
            {
                HelperMethods.SendChatMessageToPlayer(callerPlayer, HelperMethods.chatPrefix, commandName, " usage: " + commandName + " <player>");
                return;
            }

            // validate argument contents
            string playerTargetText = args.Split(' ')[1];
            Player? playerTarget = HelperMethods.FindTargetPlayer(playerTargetText);

            if (playerTarget == null)
            {
                HelperMethods.SendChatMessageToPlayer(callerPlayer, HelperMethods.chatPrefix, commandName, ": Ambiguous or invalid target");
                return;
            }

            // check immunity of target given calling admin
            if (callerPlayer != null && !callerPlayer.CanAdminTarget(playerTarget))
            {
                HelperMethods.ReplyToCommand_Player(playerTarget, "is immune due to level");
                return;
            }

            // perform command actions
            HelperMethods.ReplyToCommand(_Hello_Response_Prefix_Text.Value + (_Hello_Response_Use_Colon_Seperator.Value ? ": " : " ") + playerTarget.PlayerName);
        }

        public void Command_Secret(Player? callerPlayer, string args)
        {
            // perform command actions
            HelperMethods.ReplyToCommand(_SecretNumber_Prefix_Text.Value + _SecretNumber.Value.ToString());
        }
    }
}