﻿// title
// copyright information
// license information

using AdminExtension;
using HarmonyLib;
using Il2Cpp;
using MelonLoader;
using Silica_MelonLoader_Mod1;
using UnityEngine;

[assembly: MelonInfo(typeof(TemplateSilicaMod), "Mod Title", "1.0.0", "author")]
[assembly: MelonGame("Bohemia Interactive", "Silica")]

namespace Silica_MelonLoader_Mod1
{
    public class TemplateSilicaMod : MelonMod
    {
        static bool adminModAvailable = false;

        // use existing category for Silica preferences
        static MelonPreferences_Category? _modCategory;
        private const string ModCategory = "Silica";

        // create MelonPreferences_Entry items
        static MelonPreferences_Entry<string>? _TemplateSilica_Banner_Message;

        public override void OnInitializeMelon()
        {
            _modCategory ??= MelonPreferences.CreateCategory(ModCategory);

            // initialize any preference entries
            _TemplateSilica_Banner_Message ??= _modCategory.CreateEntry<string>("TemplateSilica_Banner_Message", "Hello World!");
        }

        public override void OnLateInitializeMelon()
        {
            adminModAvailable = RegisteredMelons.Any(m => m.Info.Name == "Admin Mod");

            if (adminModAvailable)
            {
                HelperMethods.CommandCallback templateCallback = Command_Template;
                HelperMethods.RegisterAdminCommand("!template", templateCallback, Power.Generic);
            }
            else
            {
                MelonLogger.Warning("Dependency missing: Admin Mod");
            }
        }

        public void Command_Template(Il2Cpp.Player callerPlayer, String args)
        {
            // validate argument count
            int argumentCount = args.Split(' ').Count() - 1;
            if (argumentCount > 1)
            {
                HelperMethods.ReplyToCommand(args.Split(' ')[0] + ": Too many arguments");
                return;
            }
            else if (argumentCount < 1)
            {
                HelperMethods.ReplyToCommand(args.Split(' ')[0] + ": Too few arguments");
                return;
            }

            // validate argument contents
            String sTarget = args.Split(' ')[1];
            Il2Cpp.Player? playerTarget = HelperMethods.FindTargetPlayer(sTarget);

            if (playerTarget == null)
            {
                HelperMethods.ReplyToCommand(args.Split(' ')[0] + ": Ambiguous or invalid target");
                return;
            }

            // check if needed parameters are loaded
            if (_TemplateSilica_Banner_Message == null)
            {
                MelonLogger.Warning("Missing parameter TemplateSilica_Banner_Message");
                return;
            }

            if (callerPlayer.CanAdminTarget(playerTarget))
            {
                // display banner message to player
                HelperMethods.ReplyToCommand(args.Split(' ')[0] + _TemplateSilica_Banner_Message.Value);
            }
            else
            {
                HelperMethods.ReplyToCommand_Player(playerTarget, "is immune due to level");
            }
        }
    }
}